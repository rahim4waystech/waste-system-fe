import { Component, OnInit, Input, SimpleChanges } from '@angular/core';
import { Opportunity } from '../../models/opportunity.model';
import { AccountService } from 'src/app/account/services/account.service';
import { catchError, take } from 'rxjs/operators';
import { LeadService } from 'src/app/leads/services/lead.service';
import { UserService } from 'src/app/user/services/user.service';
import { AuthService } from 'src/app/auth/services/auth.service';
import { ModalService } from 'src/app/core/services/modal.service';
import { IncumbentService } from 'src/app/account/services/incumbent.service';

@Component({
  selector: 'app-opportunity-form',
  templateUrl: './opportunity-form.component.html',
  styleUrls: ['./opportunity-form.component.scss']
})
export class OpportunityFormComponent implements OnInit {
  @Input()
  opportunity: Opportunity = new Opportunity();
  accounts: any = [];
  leads: any = [];
  users: any = [];
  accountId = -1;
  currentUser: any = {};
  statuses: any = [];
  incumbents: any = [];

  constructor(
    private accountService: AccountService,
    private leadService:LeadService,
    private authService: AuthService,
    private userService: UserService,
    private incumbentService:IncumbentService,
      private modalService: ModalService
  ) { }

  ngOnInit(): void {
    this.currentUser = this.authService.getUser();
    this.opportunity.ownerId = this.currentUser.id;
    this.opportunity.owner.id = this.currentUser.id;

    this.accountService.getAllAccountsForCustomerAndProspect()
    .pipe(catchError((e)=>{alert('Could not retrieve Accounts');return e;}))
    .pipe(take(1))
    .subscribe(accounts => {
      this.accounts = accounts;
    })

    this.leadService.getLeadStatus()
    .pipe(catchError((e)=>{alert('Could not retrieve Lead Statuses');return e;}))
    .pipe(take(1))
    .subscribe(status => {
      this.statuses = status;
    })

    this.userService.getAllActiveUsers()
    .pipe(catchError((e)=>{alert('Could not retrieve Users');return e;}))
    .pipe(take(1))
    .subscribe(users => {
      this.users = users;
    })
  }

  ngOnChanges(changes: SimpleChanges){
    // Set sites account id
    if(changes.opportunity) {
      this.getIncumbents()
    }
  }

  changeAccount(event){
    this.accountId = parseInt(event.target.value,10);

    this.updateLeads();
  }

  updateLeads(){
    this.leads = [];
    this.leadService.getLeadByAccountId(this.accountId)
    .pipe(catchError((e)=>{alert('Could not retrieve Leads');return e;}))
    .pipe(take(1))
    .subscribe(leads => {
      this.leads = leads;
    })
  }

  changeLead(event){
    const leadId = parseInt(event.target.value,10);
    this.opportunity.leadId = leadId;
    this.opportunity.lead = this.leads.filter(f=>f.id === leadId)[0];
  }

  changeStatus(event){
    const statusId = parseInt(event.target.value,10);
    this.opportunity.statusId = statusId;
    this.opportunity.status.id = statusId;
  }

  changeOwner(event){
    const ownerId = parseInt(event.target.value,10);
    this.opportunity.ownerId = ownerId;
    this.opportunity.owner.id = ownerId;
  }


  openModal(name: string) {
    this.modalService.open(name);
  }

  onSelectedAccounts($event: any) {
    this.opportunity.lead.accountId = $event.id;
    this.opportunity.lead.account = $event;

    this.getIncumbents();
  }

  getIncumbents(){
    this.incumbents = [];
    if(this.opportunity.lead !== null && this.opportunity.lead !== undefined){
      this.incumbentService.getIncumbentsByAccountId(this.opportunity.lead.accountId)
      .pipe(catchError((e)=>{alert('Could not get incumbents');return e;}))
      .pipe(take(1))
      .subscribe(incumbents => {
        console.log(incumbents)
        this.incumbents = incumbents;
      })
    }    
  }

}
